# Arabic-twitter-corpus-AJGT-
introduces an Arabic Jordanian General Tweets (AJGT) Corpus consisted of 1,800 tweets annotated as positive and negative.  Modern Standard Arabic (MSA) or Jordanian dialect. 
